public interface IPosition<E> {
    Object getData();
}
