public interface ADT {
    //nima saeidi
    public int size();
    public boolean isEmpty();
}